import os
import pytest
from datetime import datetime
from pyspark.sql import SparkSession
from scd2 import build_scd2, snapshot_to_events

@pytest.fixture(scope='session')
def spark():
    s=(SparkSession.builder.master('local[2]').appName('scd2-tests')
       .config('spark.ui.enabled','false').config('spark.sql.shuffle.partitions','2')
       .getOrCreate())
    yield s
    s.stop()

SCHEMA='customer_id long, customer_name string, city string, effective_at timestamp, event_seq long, operation string'

def events(spark, rows):
    return spark.createDataFrame([(i,n,c,datetime.fromisoformat(t),seq,op) for i,n,c,t,seq,op in rows],SCHEMA)

def history(df):
    return [(r.customer_id,r.city,str(r.effective_from),str(r.effective_to) if r.effective_to else None,r.is_current)
            for r in df.orderBy('customer_id','effective_from').collect()]

def test_multiple_changes_same_day(spark):
    df=events(spark,[(1,'Ana','Toronto','2026-11-01 09:00:00',1,'U'),
                     (1,'Ana','Ottawa','2026-11-01 12:00:00',2,'U'),
                     (1,'Ana','Windsor','2026-11-01 18:00:00',3,'U')])
    h=history(build_scd2(df))
    assert [x[1] for x in h]==['Toronto','Ottawa','Windsor']
    assert h[0][3]==h[1][2] and h[1][3]==h[2][2]
    assert [x[4] for x in h]==[False,False,True]

def test_late_arriving_effective_date(spark):
    # Late event physically appears last in the input, but belongs in the middle.
    df=events(spark,[(1,'Ana','Toronto','2026-11-01 09:00:00',1,'U'),
                     (1,'Ana','Windsor','2026-11-10 09:00:00',3,'U'),
                     (1,'Ana','Ottawa','2026-11-05 09:00:00',2,'U')])
    assert [x[1] for x in history(build_scd2(df))]==['Toronto','Ottawa','Windsor']

def test_disappearance_from_complete_snapshot(spark):
    prev=spark.createDataFrame([(1,'Ana','Toronto',datetime(2026,11,1,9),1),
                                (2,'Ben','Ottawa',datetime(2026,11,1,9),2)],
                               'customer_id long, customer_name string, city string, effective_at timestamp, event_seq long')
    current=prev.filter('customer_id=1')
    initial=snapshot_to_events(prev,None,'2026-11-01 23:59:59')
    changes=snapshot_to_events(current,prev,'2026-11-02 23:59:59',100)
    assert changes.filter("operation='D'").count()==1
    h=history(build_scd2(initial.unionByName(changes)))
    assert next(x for x in h if x[0]==2)[4] is False
    assert next(x for x in h if x[0]==2)[3]=='2026-11-02 23:59:59'
    assert next(x for x in h if x[0]==1)[4] is True

def test_duplicate_events_idempotent(spark):
    row=(1,'Ana','Toronto','2026-11-01 09:00:00',1,'U')
    assert build_scd2(events(spark,[row,row])).count()==1

def test_same_timestamp_keeps_final_sequence(spark):
    df=events(spark,[(1,'Ana','Toronto','2026-11-01 09:00:00',1,'U'),
                     (1,'Ana','Ottawa','2026-11-01 09:00:00',2,'U')])
    assert [x[1] for x in history(build_scd2(df))]==['Ottawa']

def test_conflicting_sequence_rejected(spark):
    df=events(spark,[(1,'Ana','Toronto','2026-11-01 09:00:00',1,'U'),
                     (1,'Ana','Ottawa','2026-11-01 09:00:00',1,'U')])
    with pytest.raises(ValueError,match='Conflicting'):
        build_scd2(df)

def test_deletion_and_reactivation(spark):
    df=events(spark,[(1,'Ana','Toronto','2026-11-01 09:00:00',1,'U'),
                     (1,'Ana','Toronto','2026-11-02 09:00:00',2,'D'),
                     (1,'Ana','Ottawa','2026-11-03 09:00:00',3,'U')])
    h=history(build_scd2(df))
    assert len(h)==2 and h[0][4] is False and h[1][4] is True
    assert h[0][3]=='2026-11-02 09:00:00'
