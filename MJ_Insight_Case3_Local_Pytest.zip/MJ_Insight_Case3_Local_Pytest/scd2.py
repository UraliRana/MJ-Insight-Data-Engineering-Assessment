"""SCD2 history from ordered customer change events and complete daily snapshots.

Intervals are [effective_from, effective_to); NULL effective_to means current.
Each distinct customer event must have a unique effective_at timestamp; event_seq
orders events with the same effective_at, but identical-time intermediate states
cannot have positive-duration intervals and are collapsed to the final event.
"""
from pyspark.sql import DataFrame, Window, functions as F

EVENT_COLS = ['customer_id','customer_name','city','effective_at','event_seq','operation']

def build_scd2(events: DataFrame) -> DataFrame:
    """Rebuild deterministic history from the complete, retained event log.

    operation: U (upsert), D (delete). event_seq is a monotonically increasing
    source ordering token for changes sharing an effective_at timestamp.
    """
    required = set(EVENT_COLS)
    if not required.issubset(set(events.columns)):
        raise ValueError(f'Missing columns: {sorted(required-set(events.columns))}')
    if events.filter(F.col('customer_id').isNull() | F.col('effective_at').isNull() |
                     F.col('event_seq').isNull() | ~F.col('operation').isin('U','D')).limit(1).count():
        raise ValueError('Invalid event key, effective_at, event_seq, or operation')
    # Exact duplicates are harmless; conflicting events with identical ordering
    # coordinates are rejected rather than selected nondeterministically.
    clean = events.select(*EVENT_COLS).dropDuplicates()
    conflicting = (clean.groupBy('customer_id','effective_at','event_seq')
                   .count().filter('count > 1').limit(1).count())
    if conflicting:
        raise ValueError('Conflicting events at identical customer/time/sequence')
    # When multiple changes have the same effective timestamp, only the final
    # state can be represented by a non-zero-length SCD2 interval.
    w_same = Window.partitionBy('customer_id','effective_at').orderBy(F.col('event_seq').desc())
    latest = (clean.withColumn('_rn',F.row_number().over(w_same))
              .filter('_rn=1').drop('_rn'))
    w = Window.partitionBy('customer_id').orderBy('effective_at','event_seq')
    with_prev = (latest.withColumn('_prev_op',F.lag('operation').over(w))
                 .withColumn('_prev_name',F.lag('customer_name').over(w))
                 .withColumn('_prev_city',F.lag('city').over(w)))
    # Suppress repeated unchanged upserts and consecutive deletes.
    meaningful = with_prev.filter(
        (F.col('_prev_op').isNull()) |
        (F.col('operation') != F.col('_prev_op')) |
        ((F.col('operation') == 'U') &
         (~F.col('customer_name').eqNullSafe(F.col('_prev_name')) |
          ~F.col('city').eqNullSafe(F.col('_prev_city'))))
    ).drop('_prev_op','_prev_name','_prev_city')
    w2 = Window.partitionBy('customer_id').orderBy('effective_at','event_seq')
    result = (meaningful.withColumn('effective_to',F.lead('effective_at').over(w2))
              .filter(F.col('operation')=='U')
              .select('customer_id','customer_name','city',
                      F.col('effective_at').alias('effective_from'),'effective_to',
                      F.col('effective_to').isNull().alias('is_current')))
    # A terminal deletion closes the previous U interval; no current row exists.
    return result


def snapshot_to_events(snapshot: DataFrame, previous_snapshot: DataFrame | None,
                       snapshot_at: str, start_sequence: int = 1) -> DataFrame:
    """Convert a COMPLETE snapshot to changes. Snapshots must have one row/key.

    Input: customer_id, customer_name, city, effective_at, event_seq.
    effective_at is source change time; for disappearance, snapshot_at is used.
    """
    keys = ['customer_id']
    if snapshot.groupBy(*keys).count().filter('count>1').limit(1).count():
        raise ValueError('Snapshot has multiple rows per customer; resolve source changes separately')
    if previous_snapshot is None:
        return snapshot.withColumn('operation',F.lit('U')).select(*EVENT_COLS)
    if previous_snapshot.groupBy(*keys).count().filter('count>1').limit(1).count():
        raise ValueError('Previous snapshot has multiple rows per customer')
    new = snapshot.alias('n').join(previous_snapshot.alias('p'),keys,'left')
    changes = new.filter(
        F.col('p.customer_id').isNull() |
        ~F.col('n.customer_name').eqNullSafe(F.col('p.customer_name')) |
        ~F.col('n.city').eqNullSafe(F.col('p.city'))
    ).select('n.customer_id','n.customer_name','n.city','n.effective_at','n.event_seq')
    deletions = (previous_snapshot.alias('p').join(snapshot.alias('n'),keys,'left_anti')
                 .select('p.customer_id','p.customer_name','p.city')
                 .withColumn('effective_at',F.to_timestamp(F.lit(snapshot_at)))
                 .withColumn('event_seq',F.lit(start_sequence).cast('long'))
                 .withColumn('operation',F.lit('D')))
    return changes.withColumn('operation',F.lit('U')).select(*EVENT_COLS).unionByName(deletions.select(*EVENT_COLS))
