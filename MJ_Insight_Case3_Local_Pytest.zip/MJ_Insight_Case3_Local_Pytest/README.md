# Case 3 — SCD Type 2 Customer Dimension (PySpark)

This case demonstrates a reproducible SCD Type 2 customer history using **synthetic data only**. The output uses half-open intervals `[effective_from, effective_to)`, with a null end date for the current row.

## Run locally

Install Java 17, Python 3.10–3.12, and then:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python -m pytest -q
```

## Design

`scd2.py` contains `build_scd2(events)`, which takes a **retained change-event log** (`customer_id`, `customer_name`, `city`, `effective_at`, `event_seq`, `operation`). Changes are sorted by business effective timestamp and sequence. A late change is inserted into the correct position by rebuilding the affected customer's history. Consecutive identical states are collapsed. Deletion events close the active interval; a later upsert can reactivate the customer.

`snapshot_to_events(current_snapshot, previous_snapshot, snapshot_at)` compares **complete** daily snapshots. Missing customers become deletion events at the snapshot time. A partial snapshot must **not** be treated as complete, or customers may be incorrectly closed.

A snapshot contains only one state per customer. To preserve multiple changes within the same day, the source must provide a change feed (or multiple timestamped snapshots) with `effective_at` and `event_seq`; a single end-of-day snapshot cannot recover unseen intermediate states.

## Tests and expected results

`tests/test_scd2.py` covers multiple same-day changes, late-effective changes, missing customers, replay duplicates, identical timestamps, conflicting sequence values, and deletion/reactivation. Run `python -m pytest -q` to see actual results; no test results are claimed until execution.

## Trade-offs and deeper questions

- **10× data:** Full-history window sorting/shuffling becomes expensive first. In production, persist events partitioned by customer hash, incrementally rebuild only impacted customer histories, and use Delta MERGE for affected keys. Benchmark skew and shuffle metrics.
- **Failure halfway:** Retain immutable input events and batch identifiers. Recompute deterministically, write a staging table, validate it, then atomically replace/merge affected customer histories in Delta. Retry the same batch safely; never mark a batch committed before the target transaction completes.
- **Correctness:** Assert one current row at most per customer, no overlapping validity intervals, correct effective-time ordering, and compare expected histories with actual histories using bidirectional set differences. The included pytest tests cover edge cases.

## Limitations

This local version returns a Spark DataFrame; it does not include a production Delta transaction or streaming orchestrator. It rebuilds from a complete retained event log. For equal `effective_at`, only the highest `event_seq` produces a non-zero-duration SCD2 state. If your business needs to preserve every same-instant change, store the audit event log separately. Missing customers are treated as deleted only when a feed is explicitly complete.
